import csv
import time
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import requests

def scrape_course_urls(searchurl):
    webd = webdriver.Chrome('path/to/chromedriver.exe')
    webd.get(searchurl)

    # scroll down to get all results
    last_height = webd.execute_script("return document.body.scrollHeight")
    while True:
        webd.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)
        new_height = webd.execute_script("return document.body.scrollHeight")
        if last_height == new_height:
            break
        last_height = new_height

    # load html of the page
    html = webd.page_source

    # parse with beautiful soup
    soup = BeautifulSoup(html, 'html.parser')

    # find div elements for a course
    containers = soup.find_all('div', {'class': 'course-card--container--1QM2W'})

    # iterate over all containers
    if not containers:
        return False
    for c in containers:
        # extract the link
        course_link = c.find_all('a', href=True)

        soup = BeautifulSoup(str(course_link[0]), 'html.parser')
        a_tag = soup.find('a')

        link = a_tag['href']
        print("-------------------------------------------------------------------")

        if link is not None:
            course_url = 'https://www.udemy.com' + link
            scrape_coursecontents(course_url)

    webd.quit()
    return True

def scrape_coursecontents(url):
    # specify the URL of the course page to scrape

    # configure the webdriver to use Chrome
    options = webdriver.ChromeOptions()
    options.add_argument("--enable-javascript")
    options.add_argument("--disable-web-security")
    options.add_argument("--allow-running-insecure-content")
    options.add_argument("--disable-cookie-encryption")

    driver = webdriver.Chrome(options=options)

    # send a GET request to the URL and get the HTML response
    wait = WebDriverWait(driver, 20)

    driver.get(url)

    # scroll down to get all results
    last_height = driver.execute_script("return document.body.scrollHeight")
    while True:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)
        new_height = driver.execute_script("return document.body.scrollHeight")
        if last_height == new_height:
            break
        last_height = new_height

    html = driver.page_source

    # parse the HTML using BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')

    # extract the title of the course
    title = soup.find('h1', {'class': 'clp-lead__title'}).text.strip()

    # extract the overall rating of the course (if any)
    rating_tag = soup.find('span', {'class': 'ud-heading-sm star-rating-module--rating-number--2xeHu'})
    rating = rating_tag.text.strip() if rating_tag else "Not available"

    # extract what you'll learn and what's included in the course
    what_you_learn = [item.text.strip() for item in soup.find_all('div', {'class': 'what-you-will-learn--content-spacing--3n5NU'})]

    course_content = soup.find_all('span', {'class': 'section--section-title--wcp90'})

    # extract the course content
    course_content = [item.text.strip() for item in soup.find_all('span', {'class': 'section--section-title--wcp90'})]

    # extract the course description
    description = soup.find('div', {'class': 'clp-lead__headline'}).text.strip()

    # extract the course requirements
    component_margins = soup.find_all('div', {'class': 'component-margin'})

    requirements = []
    for comp in component_margins:
        if comp.find('h2', {'class': 'ud-heading-xl requirements--title--2wsPe'}):
            requirements = [item.text.strip() for item in comp.find_all('div', {'class': 'ud-block-list-item ud-block-list-item-small ud-block-list-item-tight ud-block-list-item-neutral ud-text-sm'})]

    print("Title:", title)
    print("Rating:", rating)
    print("What you'll learn:", what_you_learn)
    print("Course content:", course_content)
    print("Description:", description)
    print("Requirements:", requirements)

    with open('course_contents.csv', mode='a', newline='', encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([title.encode('utf-8', errors='ignore').decode('utf-8'), rating.encode('utf-8', errors='ignore').decode('utf-8'),
                         [item.encode('utf-8', errors='ignore').decode('utf-8') for item in what_you_learn],
                         [item.encode('utf-8', errors='ignore').decode('utf-8') for item in course_content],
                         description.encode('utf-8', errors='ignore').decode('utf-8'),
                         [item.encode('utf-8', errors='ignore').decode('utf-8') for item in requirements]])


with open('course_contents.csv', mode='w', newline='', encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(['Title', 'Rating', 'What You\'ll Learn', 'Course Content', 'Description', 'Requirements'])
for i in range(1,1000):
    url = f'https://www.udemy.com/courses/search/?kw=deutsch&p=' + str(i) + '&q=deutsch&src=sac'
    if not scrape_course_urls(url):
        break
